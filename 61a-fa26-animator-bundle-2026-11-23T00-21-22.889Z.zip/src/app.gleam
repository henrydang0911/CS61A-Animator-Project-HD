//// Animator -- an application for program-generated drawings.

import builtins
import drawing
import editor
import errors.{type EvalError}
import gleam/float
import gleam/int
import gleam/list
import gleam/option.{type Option, None, Some}
import gleam/result
import lustre
import lustre/attribute as attr
import lustre/effect.{type Effect}
import lustre/element.{type Element}
import lustre/element/html
import lustre/event
import parser
import render
import shape.{type Path}

/// Your app's public address, once you've deployed it in Problem 13, such as
/// "https://your-username.github.io/animator/".
pub const public_url = ""

/// Set to True if you would like your app's URL included in the course gallery.
pub const include_app_in_gallery = False

/// A link to your video from Problem 14, which anyone with the link can watch.
pub const video_url = ""

/// Set to True if you would like your video included in the course gallery.
pub const include_video_in_gallery = False

const default_code = "fn draw(shape_slider: Int) -> List(Path) {
  [
    Path(Line(Point(-200, 150), Point(200, 150)), 0, 12, 4),
    Path(Line(Point(200, 150), Point(0, -180)), 8, 22, 4),
    Path(Line(Point(0, -180), Point(-200, 150)), 16, 30, 4),
  ]
}
"

/// 3Blue1Brown / Manim-style stroke palette: saturated colors on a dark stage.
const manim_palette = [
  "#58C4DD", "#83C167", "#FFFF00", "#FC6255", "#9A72AC", "#FF862F", "#FFFFFF",
]

// ── Model ──────────────────────────────────────────────────────────────────────

/// What kind of problem the red popup is reporting.
pub type ErrorKind {
  SyntaxError
  TypeError
  RuntimeError
  DrawingError
}

pub type AppError {
  AppError(kind: ErrorKind, message: String)
}

pub type Model {
  Model(
    // The code in the editor.
    source: String,
    // Whether the code editor is shown.
    code_open: Bool,
    // Shown as a small red popup while the drawing cannot run.
    error: Option(AppError),
    // Animation speed as a percent of normal: 100 = 1×,
    // negatives play backward (−500 = −5× … 500 = 5×).
    speed_percent: Int,
    // When True, the clock is frozen (rate 0) until Play.
    paused: Bool,
  )
}

pub type Msg {
  SetCode(String)
  SetSpeed(Int)
  PauseAnimation
  PlayAnimation
  RestartAnimation

  // Layout controls
  ToggleCode
}

// ── Init ───────────────────────────────────────────────────────────────────────

pub fn init(_flags: Nil) -> #(Model, Effect(Msg)) {
  #(
    Model(
      source: "",
      code_open: True,
      error: None,
      speed_percent: 100,
      paused: False,
    ),
    // Effects that happen automatically at the start go here.
    effect.batch([
      editor.mount(default_code, SetCode),
      effect.from(fn(dispatch) { dispatch(SetCode(default_code)) }),
    ]),
  )
}

// Parse and evaluate a draw function at the given shape-slider value, returning
// the paths on success, or a typed error for the popup.
fn run_source(
  shape_slider: Int,
  source: String,
) -> Result(List(Path), AppError) {
  case parser.parse_program(source, builtins.global_frame()) {
    Error(msg) -> Error(AppError(SyntaxError, msg))
    Ok(program) ->
      case drawing.try_draw(shape_slider, program) {
        Ok(paths) -> Ok(paths)
        Error(err) -> Error(classify_eval_error(err))
      }
  }
}

fn classify_eval_error(error: EvalError) -> AppError {
  let message = errors.error_message(error)
  case unwrap_line(error) {
    errors.TypeError(_) -> AppError(TypeError, message)
    errors.BadDrawing(_) | errors.PathLimit -> AppError(DrawingError, message)
    _ -> AppError(RuntimeError, message)
  }
}

fn unwrap_line(error: EvalError) -> EvalError {
  case error {
    errors.OnLine(inner, _) -> unwrap_line(inner)
    other -> other
  }
}

fn error_kind_label(kind: ErrorKind) -> String {
  case kind {
    SyntaxError -> "Syntax"
    TypeError -> "Type"
    RuntimeError -> "Runtime"
    DrawingError -> "Drawing"
  }
}

/// Turn Paths into RenderPaths with cycling Manim colours, then push them to
/// the canvas and restart the clock so each edit plays like a fresh construction.
fn animate(paths: List(Path), speed_percent: Int, paused: Bool) -> Effect(Msg) {
  let rendered =
    list.index_map(paths, fn(path, i) {
      render.render_path(path, manim_color(i))
    })
  let rate = effective_rate(speed_percent, paused)
  effect.from(fn(_) {
    render.reset_clock()
    render.set_speed(rate)
    render.set_drawing(rendered)
  })
}

fn clear_drawing() -> Effect(Msg) {
  effect.from(fn(_) {
    render.reset_clock()
    render.set_drawing([])
  })
}

fn apply_speed(speed_percent: Int, paused: Bool) -> Effect(Msg) {
  let rate = effective_rate(speed_percent, paused)
  effect.from(fn(_) { render.set_speed(rate) })
}

fn restart_animation(speed_percent: Int, paused: Bool) -> Effect(Msg) {
  let rate = effective_rate(speed_percent, paused)
  effect.from(fn(_) {
    render.reset_clock()
    render.set_speed(rate)
  })
}

/// Slider percent → canvas clock multiplier (100 → 1.0×).
fn speed_rate(speed_percent: Int) -> Float {
  int.to_float(speed_percent) /. 100.0
}

fn effective_rate(speed_percent: Int, paused: Bool) -> Float {
  case paused {
    True -> 0.0
    False -> speed_rate(speed_percent)
  }
}

fn manim_color(index: Int) -> String {
  let assert Ok(color) =
    list.drop(manim_palette, index % list.length(manim_palette))
    |> list.first
  color
}

// ── Update ─────────────────────────────────────────────────────────────────────

pub fn update(model: Model, msg: Msg) -> #(Model, Effect(Msg)) {
  case msg {
    ToggleCode -> #(Model(..model, code_open: !model.code_open), effect.none())

    SetSpeed(percent) -> {
      let speed_percent = int.clamp(percent, -500, 500)
      // Dragging the slider resumes playback at the new rate.
      let paused = False
      #(
        Model(..model, speed_percent: speed_percent, paused: paused),
        apply_speed(speed_percent, paused),
      )
    }

    PauseAnimation -> #(
      Model(..model, paused: True),
      apply_speed(model.speed_percent, True),
    )

    PlayAnimation -> {
      // If the slider is at 0×, bump to 1× so Play actually moves.
      let speed_percent = case model.speed_percent {
        0 -> 100
        n -> n
      }
      #(
        Model(..model, paused: False, speed_percent: speed_percent),
        apply_speed(speed_percent, False),
      )
    }

    RestartAnimation -> #(
      model,
      restart_animation(model.speed_percent, model.paused),
    )

    // After each keystroke in the editor, evaluate user code and animate (or
    // report an error).
    SetCode(text) ->
      case run_source(10, text) {
        Ok(paths) -> #(
          Model(..model, error: None, source: text),
          animate(paths, model.speed_percent, model.paused),
        )
        Error(err) -> #(
          Model(..model, error: Some(err), source: text),
          clear_drawing(),
        )
      }
  }
}

// ── View ──────────────────────────────────────────────────────────────────
//
// Two side-by-side panes: the code editor on the left and its rendered output on
// the right. The code column can be hidden to expand the right pane.

pub fn view(model: Model) -> Element(Msg) {
  let app_class = case model.code_open {
    True -> "app"
    False -> "app code-hidden"
  }
  // The code column still exists even when hidden (CSS collapses it) so the
  // mounted CodeMirror editor keeps its state across show/hide.
  html.div([attr.class(app_class)], [
    html.div([attr.class("code-col")], [
      editor.view_panel(ToggleCode),
    ]),
    view_anim(model),
  ])
}

fn view_anim(model: Model) -> Element(Msg) {
  html.div([attr.class("canvas-area")], [
    view_reveal_code(model),
    view_speed_control(model),
    html.canvas([attr.id("animation-canvas"), attr.class("canvas")]),
    view_error(model),
  ])
}

fn view_speed_control(model: Model) -> Element(Msg) {
  let label =
    "Speed "
    <> float.to_string(speed_rate(model.speed_percent))
    <> "×"
  html.div([attr.class("anim-controls")], [
    html.label([attr.class("slider-label")], [
      html.span([], [html.text(label)]),
      html.input([
        attr.type_("range"),
        attr.min("-500"),
        attr.max("500"),
        attr.step("25"),
        attr.value(int.to_string(model.speed_percent)),
        attr.attribute("data-test-id", "speed-slider"),
        attr.attribute("title", "Animation speed (−5× to 5×)"),
        event.on_input(fn(raw) {
          SetSpeed(result.unwrap(int.parse(raw), model.speed_percent))
        }),
      ]),
    ]),
    html.div([attr.class("playback-btns")], [
      html.button(
        [
          attr.class(case model.paused {
            False -> "icon-btn icon-btn-active"
            True -> "icon-btn"
          }),
          attr.attribute("title", "Play"),
          attr.type_("button"),
          attr.disabled(!model.paused && model.speed_percent != 0),
          event.on_click(PlayAnimation),
        ],
        [html.text("▶")],
      ),
      html.button(
        [
          attr.class(case model.paused {
            True -> "icon-btn icon-btn-active"
            False -> "icon-btn"
          }),
          attr.attribute("title", "Pause"),
          attr.type_("button"),
          attr.disabled(model.paused),
          event.on_click(PauseAnimation),
        ],
        [html.text("❚❚")],
      ),
      html.button(
        [
          attr.class("icon-btn"),
          attr.attribute("title", "Restart animation"),
          attr.type_("button"),
          event.on_click(RestartAnimation),
        ],
        [html.text("↻")],
      ),
    ]),
  ])
}

fn view_error(model: Model) -> Element(Msg) {
  case model.error {
    None -> element.none()
    Some(AppError(kind, message)) ->
      html.div(
        [
          attr.class("error-popup"),
          attr.attribute("role", "alert"),
        ],
        [
          html.span([attr.class("error-popup-kind")], [
            html.text(error_kind_label(kind)),
          ]),
          html.span([attr.class("error-popup-msg")], [html.text(message)]),
        ],
      )
  }
}

// The button that brings the code column back, overlaid on the top-left of the
// right pane. Nothing is rendered while the column is already showing (its own
// header holds the button that hides it).
fn view_reveal_code(model: Model) -> Element(Msg) {
  case model.code_open {
    True -> element.none()
    False ->
      html.button(
        [
          attr.class("icon-btn reveal-code"),
          attr.attribute("title", "Show code"),
          event.on_click(ToggleCode),
        ],
        [html.text("⟩")],
      )
  }
}

// ── Main ───────────────────────────────────────────────────────────────────────

pub fn main() -> Nil {
  let app = lustre.application(init, update, view)
  let assert Ok(_) = lustre.start(app, "#app", Nil)
  Nil
}
